/**
 * @lexicallayer/sdk
 * Programmatic SDK for AI Agents to connect with calibrated user weights.
 */

class LexicalLayer {
  constructor(options = {}) {
    this.baseUrl = options.baseUrl || "http://127.0.0.1:8001";
    this.agentName = options.agentName || "default-agent";
  }

  /**
   * Initializes a handshake session and returns the Studio URL.
   */
  async createCalibrationSession() {
    const res = await fetch(`${this.baseUrl}/api/session/init`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agent_name: this.agentName, email: "agent@runtime.local" })
    });
    const data = await res.json();
    return {
      sessionId: data.session.id,
      studioUrl: `http://localhost:3000/studio?session=${data.session.id}`
    };
  }

  /**
   * Waits until the user approves the weights in Studio.
   */
  async waitForApproval(sessionId, timeoutSeconds = 300) {
    const start = Date.now();
    while ((Date.now() - start) < timeoutSeconds * 1000) {
      const res = await fetch(`${this.baseUrl}/api/session/verify/${sessionId}`);
      const data = await res.json();
      if (data?.session?.approved) {
        return {
          approved: true,
          adapterFile: data.session.adapter_filename,
          session: data.session
        };
      }
      await new Promise(r => setTimeout(r, 2000));
    }
    throw new Error("Kalibrasyon oturumu zaman aşımına uğradı.");
  }

  /**
   * Performs steered inference with the user's calibrated weights.
   */
  async generate({ prompt, useUserWeights = true, model = "meta-llama/Llama-3.1-8B-Instruct" }) {
    const res = await fetch(`${this.baseUrl}/api/user-weights/test`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, use_user_weights: useUserWeights, model })
    });
    return await res.json();
  }
}

module.exports = { LexicalLayer };
